package takeaway.controller;

import takeaway.action.Business;
import takeaway.action.LoginWithBus;
import takeaway.services.loginServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @description:
 * @Time: 2019/1/9 22:12
 */
@WebServlet(name = "RegisterBusServlet")
public class RegisterBusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String userName=request.getParameter("userName");
        String password=request.getParameter("password");
        String nickName=request.getParameter("XiaoName");
        String tel=request.getParameter("Tel");
        String addr=request.getParameter("addr");

        Business business=new Business(tel,"businessman",nickName,addr);
        LoginWithBus loginWithBus=new LoginWithBus(password,"businessman",userName,business);

        loginServiceImpl loginService=new loginServiceImpl();
        loginService.newLogin(loginWithBus);

        loginService.newShop(loginWithBus);

        request.getSession().setAttribute("identity","商家");
        request.getRequestDispatcher("overReg.jsp").forward(request,response);


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
