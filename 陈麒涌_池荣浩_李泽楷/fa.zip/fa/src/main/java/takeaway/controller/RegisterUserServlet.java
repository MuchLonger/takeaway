package takeaway.controller;

import takeaway.action.LoginWithUser;
import takeaway.action.User;
import takeaway.services.loginServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;

/**
 * @description:
 * @Time: 2019/1/9 20:15
 */
@WebServlet(name = "RegisterServlet")
public class RegisterUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String userName=request.getParameter("userName");
        String password=request.getParameter("password");
        String nickName=request.getParameter("XiaoName");
        String tel=request.getParameter("Tel");
        String addr=request.getParameter("addr");

        User user=new User(addr,new Timestamp(System.currentTimeMillis()),"user",tel,nickName);
        LoginWithUser loginWithUser=new LoginWithUser(password,"user",userName,user);

        loginServiceImpl loginService=new loginServiceImpl();
        loginService.newLogin(loginWithUser);

        loginService.newUser(loginWithUser);

        request.getSession().setAttribute("identity","会员");
        request.getRequestDispatcher("overReg.jsp").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
