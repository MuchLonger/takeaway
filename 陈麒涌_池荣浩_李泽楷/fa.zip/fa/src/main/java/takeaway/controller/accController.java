package takeaway.controller;

import takeaway.action.User;
import takeaway.services.loginServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @description:
 * @Time: 2019/1/10 22:08
 */
@WebServlet(name = "accController")
public class accController extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=utf-8");

        Integer goToUserNum=(Integer)request.getSession().getAttribute("goToUserNum");

        loginServiceImpl loginService = new loginServiceImpl();

        User user=loginService.getUser(goToUserNum);

        request.getSession().setAttribute("user",user);
        request.getSession().setAttribute("userName",user.getUserName());
        request.getSession().setAttribute("userTel",user.getUserTel());

        request.getRequestDispatcher("account.jsp").forward(request,response);
    }
}
