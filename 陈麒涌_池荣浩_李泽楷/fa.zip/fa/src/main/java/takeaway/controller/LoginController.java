package takeaway.controller;

import takeaway.action.Business;
import takeaway.action.Login;
import takeaway.action.User;
import takeaway.services.loginServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @description:
 * @Time: 2019/1/8 9:56
 */
public class LoginController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=UTF-8");

        System.out.println("login");

        String account = req.getParameter("account");
        String password = req.getParameter("password");

        loginServiceImpl loginService = new loginServiceImpl();
        Login log = loginService.login(account, password);
        if (log != null) {
            if (log.getRole().equals("user")) {
                User user = loginService.getUser(log.getGoToUserNum());
                req.getSession().setAttribute("userName", user.getUserName());
                req.getSession().setAttribute("goToUserNum",user.getGoToUserNum());
                req.getSession().setAttribute("role", "会员");
            } else if (log.getRole().equals("businessman")) {
                Business business = loginService.getBusiness(log.getGoToUserNum());
                req.getSession().setAttribute("userName", business.getShopName());
                req.getSession().setAttribute("role", "商家");
            }
            resp.sendRedirect(getServletContext().getContextPath() + "index.jsp");
        } else {
            req.setAttribute("error", "你的账户不存在");
            req.getRequestDispatcher("login.jsp").forward(req, resp);
        }

    }
}
