package takeaway.services;

import org.apache.ibatis.session.SqlSession;
import takeaway.Utils.MybatisUitl;
import takeaway.action.*;
import takeaway.dao.login.LoginMapper;

import java.util.List;

/**
 * @description:
 * @Time: 2019/1/8 10:56
 */
public class loginServiceImpl implements loginService {
    private LoginMapper loginMapper=null;
    private SqlSession sqlSession;
    @Override
    public Login login(String userAccount, String userPassword) {
        sessionOpen();

        Login log=new Login(userAccount,userPassword);

        Login user=loginMapper.pull(log);

        sessionClose();
        return user;
    }

    @Override
    public User getUser(Integer goToUserNum) {
        sessionOpen();
        User user=loginMapper.getUser(goToUserNum.intValue());

        sessionClose();
        return user;
    }

    @Override
    public Business getBusiness(Integer goToUserNum) {
        sessionOpen();
        Business business=loginMapper.getBusiness(goToUserNum.intValue());

        sessionClose();
        return business;
    }

    /**
     * 加入login对象，并添加进数据库
     * @param login
     */
    @Override
    public void newLogin(Login login) {
        sessionOpen();

        loginMapper.newLogin(login);

        Commit();
    }

    @Override
    public Integer getNum(String account) {
        sessionOpen();

        Integer num=loginMapper.getNum(account);

        return num;
    }


    @Override
    public void newUser(LoginWithUser loginWithUser) {
        sessionOpen();

        //获取对应的num值
        Integer num=getNum(loginWithUser.getAccount());

        loginMapper.newUser(loginWithUser.getUser(),num);

        Commit();
        sessionClose();
    }

    @Override
    public void newShop(LoginWithBus loginWithBus) {
        sessionOpen();

        Integer num=getNum(loginWithBus.getAccount());
        loginMapper.newShop(loginWithBus.getBusiness(),num);

        Commit();
        sessionClose();
    }

    @Override
    public List<Business> getBusList(String addr) {
        sessionOpen();

        List<Business> list=loginMapper.getBusinessList(addr);

        sessionClose();
        return list;
    }

    @Override
    public List<Order> getOrderList(Integer goToUserNum) {
        sessionOpen();

        List<Order> list=loginMapper.getOrderList(goToUserNum);

        sessionClose();
        return list;
    }

    @Override
    public Business getBusinessByName(String shopName) {
        sessionOpen();

        Business business=loginMapper.getBusinessByName(shopName);

        sessionClose();
        return business;
    }

    @Override
    public List<Login> getLoginByAll() {
        sessionOpen();

        List<Login> logins=loginMapper.getLoginByAll();

        sessionClose();
        return logins;
    }

    @Override
    public Login getLoginByNum(Integer goToUserNum) {
        sessionOpen();

        Login login=loginMapper.getLoginByNum(goToUserNum);

        sessionClose();
        return login;
    }

    //获取LoginMapper的mybatis流
    private void sessionOpen(){
        sqlSession=MybatisUitl.getSession();
        loginMapper=sqlSession.getMapper(LoginMapper.class);
    }
    //关闭流
    private void sessionClose(){
        if(sqlSession!=null){
            sqlSession.close();
        }
    }
    //事务提交，在使用完insert或delete或update完之后使用
    private void Commit(){
        sqlSession.commit();
    }
}
