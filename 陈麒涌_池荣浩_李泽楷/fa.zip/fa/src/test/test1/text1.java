package test1;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import takeaway.Utils.MybatisUitl;
import takeaway.action.*;
import takeaway.dao.login.LoginMapper;
import takeaway.services.loginServiceImpl;

import java.sql.Timestamp;
import java.util.List;

/**
 * @description:
 * @Time: 2019/1/8 9:17
 */
public class text1 {
    @Test
    public void test1() {
        System.out.println("1login");

        //先获取账号，密码

        SqlSession sqlSession = MybatisUitl.getSession();
        LoginMapper log = sqlSession.getMapper(LoginMapper.class);
        Login l1 = new Login("502", "cqy", 1, "abc");
        Login l2 = log.pull(l1);
        System.out.println(l2.getRole());


        if (sqlSession != null) {
            sqlSession.close();
        }
    }

    @Test
    public void m1() {
        SqlSession sqlSession = MybatisUitl.getSession();
        LoginMapper loginMapper = sqlSession.getMapper(LoginMapper.class);
        User user = new User("连南", new Timestamp(System.currentTimeMillis()), "user","333", "晨曲");
        LoginWithUser loginWithUser = new LoginWithUser("567", "user", "cyy", user);

        loginMapper.newUser(loginWithUser.getUser(),3);

        sqlSession.commit();

        if (sqlSession != null) {
            sqlSession.close();
        }
    }

    @Test
    public void m2(){
        SqlSession sqlSession=MybatisUitl.getSession();
        LoginMapper loginMapper=sqlSession.getMapper(LoginMapper.class);

        Integer s=loginMapper.getNum("cqy");
        System.out.println(s);
        if (sqlSession != null) {
            sqlSession.close();
        }
    }

    @Test
    public void m3(){
        SqlSession sqlSession=MybatisUitl.getSession();
        LoginMapper loginMapper=sqlSession.getMapper(LoginMapper.class);

        List<Business> list=loginMapper.getBusinessList("天河");

        for (Business business:
             list) {
            System.out.println(business.getShopName());
        }

        if(sqlSession!=null){
            sqlSession.close();
        }
    }

    @Test
    public void m4(){
        SqlSession sqlSession=MybatisUitl.getSession();
        LoginMapper loginMapper=sqlSession.getMapper(LoginMapper.class);

        List<Order> list=loginMapper.getOrderList(25);


        for (Order owu :
                list) {
            System.out.println(owu.getShopName());
        }

        if(sqlSession!=null){
            sqlSession.close();
        }
    }

    @Test
    public void m5(){
        loginServiceImpl loginService=new loginServiceImpl();

        Business b=loginService.getBusinessByName("北苑饭堂");

        System.out.println(b.getShopAddress());
    }

    @Test
    public void m6(){
        loginServiceImpl loginService=new loginServiceImpl();

        List<Login> logins=loginService.getLoginByAll();

        for (Login l:
             logins) {
            System.out.println(l.getAccount());
        }

    }

}
